// Open and Close Popup Logic
function openPopup(popupId) {
    document.getElementById(popupId).style.display = 'block';
    document.querySelector('.overlay').style.display = 'block';
}

function closePopup(popupId) {
    document.getElementById(popupId).style.display = 'none';
    document.querySelector('.overlay').style.display = 'none';
}

// Open Outlet Page
function redirectToOutlet(outlet) {
    window.location.href = `/outlets/${outlet}.html`;
}

// Navigation to Homepage
function goToHomePage() {
    window.location.href = "index.html";
}

// Explore Outlets Redirect
document.getElementById("explore-btn")?.addEventListener("click", () => {
    window.location.href = "outlets.html";
});

// Close Popups on Clicking Outside
document.querySelector('.overlay').addEventListener('click', function() {
    closePopup('login-popup');
    closePopup('signup-popup');
});
